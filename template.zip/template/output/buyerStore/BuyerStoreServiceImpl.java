package com.yuanpin.flora.biz.store.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service;
 
import com.yuanpin.flora.biz.base.BaseServiceImpl;
import com.yuanpin.flora.biz.store.BuyerStoreService;
import com.yuanpin.flora.dao.store.BuyerStoreDao;
import com.yuanpin.shared.entity.store.BuyerStore;


@Service
public class BuyerStoreServiceImpl extends BaseServiceImpl  implements BuyerStoreService{

  @Autowired
  private BuyerStoreDao buyerStoreDao;

  public List<BuyerStore> getAll() {
    return super.getAll(buyerStoreDao);
  }

  public BuyerStore getById(Long id) {
    return super.getById(buyerStoreDao, id);
  }

  public boolean save(BuyerStore buyerStore) {
    return super.save(buyerStoreDao, buyerStore);
  }

  public boolean deleteById(Long id) {
    return super.deleteById(buyerStoreDao, id);
  }

  public int deleteByIds(Long[] ids) {
    return super.deleteByIds(buyerStoreDao, ids);
  }
}
