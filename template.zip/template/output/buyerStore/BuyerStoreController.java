package null.store;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tqmall.base.pvg.PrivilegeInfo;
import com.tqmall.saint.biz.common.DefaultPage;
import com.yuanpin.flora.biz.store.impl.BuyerStoreServiceImpl;
import com.tqmall.saint.common.Result;
import com.tqmall.saint.common.SaintError;
import com.yuanpin.shared.entity.store.BuyerStore;
import com.tqmall.saint.web.common.BaseController;
import com.tqmall.saint.web.common.SaintPageRequest;
import ${inputVO_java_vm_pkgPrefix}.BuyerStoreInputVO;
import ${resultVO_java_vm_pkgPrefix}.BuyerStoreResultVO;
import com.tqmall.saint.web.utils.bean.SaintBeanUtils;

@Controller
@RequestMapping(value = "/flora/buyerStore")
public class BuyerStoreController extends BaseController {

    @Autowired
    private BuyerStoreServiceImpl buyerStoreService;

    @Autowired
    private PrivilegeInfo pvgInfo;

    @Autowired
    private SaintBeanUtils saintBeanUtils;

    private Logger logger = LoggerFactory.getLogger(BuyerStoreController.class);

    private final String  buyerStorePath = "/flora/store/";

    @RequestMapping(value = "search", method = RequestMethod.POST)
    @ResponseBody
    public Result<?> search(
            @RequestBody SaintPageRequest pageRequest
    ) {
        Map<String, Object> searchParams = pageRequest.getParams();
        Page<BuyerStoreResultVO> resultPage = this.search(searchParams, pageRequest);
        if (resultPage == null) {
            return Result.wrapErrorResult(SaintError.COMMON_ERROR);
        }
        return Result.wrapSuccessfulResult(resultPage);
    }

    protected Page<BuyerStoreResultVO> search(Map<String, Object> searchParams, Pageable pageable) {
        Page<BuyerStore> page = buyerStoreService.getPage(pageable, searchParams);
        PageRequest pageRequest = new PageRequest(page.getNumber(), page.getSize(), page.getSort());
        List<BuyerStoreResultVO> BuyerStoreResults = new ArrayList<BuyerStoreResultVO>();
        for (BuyerStore buyerStore : page.getContent()) {
            BuyerStoreResultVO buyerStoreResultVO = new BuyerStoreResultVO();
            try {
                BeanUtils.copyProperties(buyerStoreResultVO, buyerStore);
            } catch (Exception e) {
                logger.error("copy propertis error");
                return null;
            }
                BuyerStoreResults.add(buyerStoreResultVO);
        }
        Page<BuyerStoreResultVO> resultPage =
                new DefaultPage<BuyerStoreResultVO>(BuyerStoreResults, pageRequest, page.getTotalElements());
        return resultPage;
    }

    @RequestMapping(value = "save", method = RequestMethod.POST)
    @ResponseBody
    public Result<?> save(@Valid BuyerStoreInputVO buyerStoreInputVO) {
        BuyerStore buyerStore = new BuyerStore();
        try {
            BeanUtils.copyProperties(buyerStore, buyerStoreInputVO);
        } catch (Exception e) {
            logger.error("copy propertis error");
            return Result.wrapErrorResult(SaintError.PARAM_ERROR);
        }

        if (buyerStore.getId() == null) {
                buyerStore.setCreator(pvgInfo.getUserId());
        }
            buyerStore.setModifier(pvgInfo.getUserId());
        boolean bResult = false;

        try{
            bResult = this.buyerStoreService.save(buyerStore);
        }catch(Exception e){
            logger.error("",e);
            return Result.wrapErrorResult(SaintError.COMMON_ERROR);
        }
        if (!bResult) {
            return Result.wrapErrorResult(SaintError.COMMON_ERROR);
        }
        return Result.wrapSuccessfulResult(null);
    }

    @RequestMapping(value = "delete", method = RequestMethod.POST)
    @ResponseBody
    public Result<?> save(@RequestParam Long id) {
        boolean bResult = false;
        try{
            bResult = this.buyerStoreService.deleteById(id);
        }catch(Exception e){
            logger.error("",e);
            return Result.wrapErrorResult(SaintError.COMMON_ERROR);
        }
        if (!bResult) {
            return Result.wrapErrorResult(SaintError.COMMON_ERROR);
        }
        return Result.wrapSuccessfulResult(null);
    }

    @RequestMapping(value = "/list")
    public String list(ModelMap model) {
        String contextPath = this.getRequest().getContextPath();
        logger.info("context path:" + contextPath);
        return buyerStorePath+"/buyerStoreList";
    }

    @RequestMapping(value = "/detail/{id}")
    public String detail(ModelMap model, @PathVariable Long id) {
        String contextPath = this.getRequest().getContextPath();
        BuyerStore buyerStore = this.buyerStoreService.getById(id);
        if (buyerStore != null) {
            try {
                BuyerStoreResultVO buyerStoreResultVO = new BuyerStoreResultVO();
                BeanUtils.copyProperties(buyerStoreResultVO, buyerStore);
                model.put("item", buyerStoreResultVO);
            } catch (Exception e) {
                logger.error("copy propertis error");
            }
        }
        logger.info("context path:" + contextPath);
        return buyerStorePath + "buyerStoreDetail";
    }

    @RequestMapping(value = "/add")
    public String add(ModelMap model) {
        String contextPath = this.getRequest().getContextPath();
        logger.info("context path:" + contextPath);
        return buyerStorePath+"buyerStoreAdd";
    }
}
