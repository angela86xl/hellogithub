package null.store;

import java.util.Date;
import lombok.Data;
import com.tqmall.common.util.DateUtil;

@Data
public class BuyerStoreResultVO{

  private Long id;
  private Long userId;
  private String buyerStoreName;
  private String buyerContactName;
  private String buyerContactMobile;
  private String buyerContactPhone;
  private String buyerWechat;
  private Long buyerStoreProvinceId;
  private Long buyerStoreCityId;
  private Long buyerStoreDistrictId;
  private Long buyerStoreStreetId;
  private String buyerStoreAddress;
  private String buyerStorePhoto;
  private String buyerStoreBrief;
  private BigDecimal buyerLon;
  private BigDecimal buyerLat;
  private String remark;


}
