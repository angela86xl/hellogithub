package com.yuanpin.shared.entity.store;

import java.math.BigDecimal;


import lombok.Data;
import lombok.EqualsAndHashCode;

import com.yuanpin.shared.entity.base.BaseEntity;

@EqualsAndHashCode(callSuper = false)
@Data
public class BuyerStore extends BaseEntity {

  private Long userId;
  private String buyerStoreName;
  private String buyerContactName;
  private String buyerContactMobile;
  private String buyerContactPhone;
  private String buyerWechat;
  private Long buyerStoreProvinceId;
  private Long buyerStoreCityId;
  private Long buyerStoreDistrictId;
  private Long buyerStoreStreetId;
  private String buyerStoreAddress;
  private String buyerStorePhoto;
  private String buyerStoreBrief;
  private BigDecimal buyerLon;
  private BigDecimal buyerLat;
  private String remark;

}
