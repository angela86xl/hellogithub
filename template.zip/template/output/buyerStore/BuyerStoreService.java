package com.yuanpin.flora.biz.store;

import java.util.List;
import java.util.Map;

import com.yuanpin.shared.entity.store.BuyerStore;

public interface BuyerStoreService {
  public List<BuyerStore> getAll();
  
  public BuyerStore getById(Long id);

  public boolean save(BuyerStore buyerStore);

  public boolean deleteById( Long id);

  public  int deleteByIds(Long[] ids);

}
