/*
 * Filename:buyerStoreList.js
 */

RequestBuyerStoreSearch = extend(RequestPageBase, function(searchParam, pageData, sort) {
    this.__super__.constructor(this, searchParam, pageData, sort);
    this.url = "crm/buyerStore/search";
});

RequestBuyerStoreDelete = extend(RequestBase, function(id) {
    this.__super__.constructor(this);
    this.url = "crm/buyerStore/delete";
    this.method = "post";
    this.params = {};
    this.params.id = id;
});


/*
 * View 初始化处理
 * */
function initView() {
    initDateTimePicker($('.datetime-picker'));
    var pageContainer = new PageContainer({
        id: 'pageContainer',
        defaultSize: 50,
        valueChangedCallback: function(pageData) {
            search( pageData );
        }
    });

    gViewModel['pageContainer'] = pageContainer;
}

/*
 * View Handler 初始化处理
 * */
function setViewHandlers() {
    $('#btnSearch').bind('click', btnSearchKeyClicked);
    $('#buyerStore_table').on('click','button.del',itemDeleteButtonClicked)
        .on('click', 'th.sortable', tableHeadClicked);
}

function itemDeleteButtonClicked(e){
    item = $(this).closest('tr').data('item');
    e.stopPropagation();
    if( !item ){
        return;
    }
    deleteItem(item);
}

function tableHeadClicked() {
    var $this = $(this);
    if (!$this.hasClass("sortable")) {
        return;
    }
    baseSetNextSortOrder($this);
    search();
}

function btnSearchKeyClicked(e) {
    search();
}

function search( parmPageData ) {

    baseShowIndicator(true);
    var pageContainer = gViewModel['pageContainer'];
    if (!pageContainer) {
        return;
    }
    var searchParam = getSearchParam();
    var pageData = parmPageData;
    if( !pageData ){
      pageData = pageContainer.getPageData();
    }
    
    var sort = baseGetSortData($('#buyerStore_table tr.table-head'));
    var pageContainer = gViewModel['pageContainer'];
    var net = Net.getInstance();
    var request = new RequestBuyerStoreSearch(searchParam, pageData, sort);
    var success = function(result) {
        baseShowIndicator(false);
        if (result.success) {
            var data = result.data;
            pageContainer.setPageData(data);
            resetBuyerStoreTableContent(data.content);
        } else {
            baseShowModalAlert('danger', result.errorMsg);
        }
    };
    net.request(request, success);
}

function deleteItem(item){
    baseShowModalAlert('danger'
        ,'是否删除此条记录'
        , {
            confirm:{}
            ,cancel:{}
        }
        ,function(e){
            if( e.method == 'confirm'){
                setTimeout( exectDeleteItem , 500 , item );
            }
        }
    );
}

function exectDeleteItem(item){
    var request = new RequestBuyerStoreDelete(item.id);
    var net = Net.getInstance();
    var success = function(result) {
        if (result.success) {
            baseShowModalAlert('success',
                "删除成功",
                null,
                function(e) {
                    search();
                },
                1500
            );
        } else {
            baseShowModalAlert('danger', result.errorMsg);
        }
    };
    net.request(request, success);
}

function resetBuyerStoreTableContent(items) {
    var html = '';
    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        var line = '<tr id="buyerStore_item_' + item.id + '" class="table-line">'
              + '<td><a href="./detail/'+item.id+'" target="_blank">' + item.userId + '</a></td>'
                + '<td>' + item.buyerStoreName + '</td>'
                + '<td>' + item.buyerContactName + '</td>'
                + '<td>' + item.buyerContactMobile + '</td>'
                + '<td>' + item.buyerContactPhone + '</td>'
                + '<td>' + item.buyerWechat + '</td>'
                + '<td>' + item.buyerStoreProvinceId + '</td>'
                + '<td>' + item.buyerStoreCityId + '</td>'
                + '<td>' + item.buyerStoreDistrictId + '</td>'
                + '<td>' + item.buyerStoreStreetId + '</td>'
                + '<td>' + item.buyerStoreAddress + '</td>'
                + '<td>' + item.buyerStorePhoto + '</td>'
                + '<td>' + item.buyerStoreBrief + '</td>'
                + '<td>' + item.buyerLon + '</td>'
                + '<td>' + item.buyerLat + '</td>'
                + '<td>' + item.remark + '</td>'
              + '<td> <button class="btn btn-danger btn-sm del">删除</button></td>'
            + '</tr>';
        html += line;
    }
    $('#buyerStore_table .table-line').remove();
    $('#buyerStore_table tbody').append(html);
    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        $('#buyerStore_item_' + item.id).data('item', item);
    }
}

function getSearchParam() {
    var searchParam = {};
    var value = null;
      value = $('#inputSPUserId').val();
    searchParam.userId = value ? value : null;
        value = $('#inputSPBuyerStoreName').val();
    searchParam.buyerStoreName = value ? value : null;
        value = $('#inputSPBuyerContactName').val();
    searchParam.buyerContactName = value ? value : null;
        value = $('#inputSPBuyerContactMobile').val();
    searchParam.buyerContactMobile = value ? value : null;
        value = $('#inputSPBuyerContactPhone').val();
    searchParam.buyerContactPhone = value ? value : null;
        value = $('#inputSPBuyerWechat').val();
    searchParam.buyerWechat = value ? value : null;
        value = $('#inputSPBuyerStoreProvinceId').val();
    searchParam.buyerStoreProvinceId = value ? value : null;
        value = $('#inputSPBuyerStoreCityId').val();
    searchParam.buyerStoreCityId = value ? value : null;
        value = $('#inputSPBuyerStoreDistrictId').val();
    searchParam.buyerStoreDistrictId = value ? value : null;
        value = $('#inputSPBuyerStoreStreetId').val();
    searchParam.buyerStoreStreetId = value ? value : null;
        value = $('#inputSPBuyerStoreAddress').val();
    searchParam.buyerStoreAddress = value ? value : null;
        value = $('#inputSPBuyerStorePhoto').val();
    searchParam.buyerStorePhoto = value ? value : null;
        value = $('#inputSPBuyerStoreBrief').val();
    searchParam.buyerStoreBrief = value ? value : null;
        value = $('#inputSPBuyerLon').val();
    searchParam.buyerLon = value ? value : null;
        value = $('#inputSPBuyerLat').val();
    searchParam.buyerLat = value ? value : null;
        value = $('#inputSPRemark').val();
    searchParam.remark = value ? value : null;
  
    return searchParam;
}
