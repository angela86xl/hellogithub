package null.store;

import java.math.BigDecimal;
import javax.validation.constraints.NotNull;
import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;


@Data
public class BuyerStoreInputVO{

  private Long id;

  private Long userId;

  private String buyerStoreName;

  private String buyerContactName;

  private String buyerContactMobile;

  private String buyerContactPhone;

  private String buyerWechat;

  private Long buyerStoreProvinceId;

  private Long buyerStoreCityId;

  private Long buyerStoreDistrictId;

  private Long buyerStoreStreetId;

  private String buyerStoreAddress;

  private String buyerStorePhoto;

  private String buyerStoreBrief;

  private BigDecimal buyerLon;

  private BigDecimal buyerLat;

  private String remark;

}
