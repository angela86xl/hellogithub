package com.yuanpin.flora.dao.store;

import com.yuanpin.flora.dao.base.BaseDao;
import com.yuanpin.flora.dao.common.MyBatisRepository;
import com.yuanpin.shared.entity.store.BuyerStore;

@MyBatisRepository
public interface BuyerStoreDao extends BaseDao<BuyerStore> {

}
